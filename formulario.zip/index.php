<?php
// Habilitar reporte de errores para depuración
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Database connection
require_once 'config/config.php';

// Status message handling
$statusMessage = '';
$statusClass = '';

if (isset($_GET['status'])) {
    // Store status in session
    $_SESSION['status'] = $_GET['status'];
    $_SESSION['status_time'] = time();
    
    // Redirect to clean URL if coming from a status parameter
    header("Location: index.php");
    exit;
}

// Check if we have a status in session that's less than 5 minutes old
if (isset($_SESSION['status']) && isset($_SESSION['status_time']) && (time() - $_SESSION['status_time'] < 300)) {
    $status = $_SESSION['status'];
    
    switch ($status) {
        case 'approved':
            $statusMessage = 'El permiso ha sido aprobado exitosamente.';
            $statusClass = 'alert-success';
            break;
        case 'rejected':
            $statusMessage = 'El permiso ha sido rechazado y se ha enviado una notificación al solicitante.';
            $statusClass = 'alert-danger';
            break;
    }
}

// Clear old status messages (older than 5 minutes)
if (isset($_SESSION['status_time']) && (time() - $_SESSION['status_time'] >= 300)) {
    unset($_SESSION['status']);
    unset($_SESSION['status_time']);
}

// Fetch permits data - Asegurarse de que los estados se carguen correctamente
// Modificar la consulta SQL para obtener los permisos con su estado actual
// Modificar la consulta SQL para asegurar que los estados se carguen correctamente
try {
    // Base query
    $baseQuery = "SELECT v.id as vehiculo_id, v.placa_patente, u.nombre, u.apellido_paterno, u.apellido_materno, 
              LOWER(s.estado) as estado, s.fecha_solicitud, s.fecha_actualizacion, u.rut 
              FROM vehiculos v 
              JOIN usuarios u ON v.usuario_id = u.id 
              JOIN solicitudes s ON v.id = s.vehiculo_id";
    
    // Filtro por estado si está especificado
    $filtroEstado = isset($_GET['estado']) ? $_GET['estado'] : '';
    $whereClause = '';
    
    if ($filtroEstado && in_array($filtroEstado, ['pendiente', 'aprobada', 'rechazada'])) {
        $whereClause = " WHERE LOWER(s.estado) = :estado";
    }
    
    // Búsqueda por texto si está especificada
    $busqueda = isset($_GET['busqueda']) ? trim($_GET['busqueda']) : '';
    if (!empty($busqueda)) {
        $whereClause = empty($whereClause) ? " WHERE " : $whereClause . " AND ";
        $whereClause .= "(v.placa_patente LIKE :busqueda OR u.rut LIKE :busqueda OR 
                       CONCAT(u.nombre, ' ', u.apellido_paterno, ' ', u.apellido_materno) LIKE :busqueda)";
    }
    
    // Ordenar por fecha de solicitud descendente
    $orderClause = " ORDER BY s.fecha_solicitud DESC";
    
    // Construir consulta completa
    $query = $baseQuery . $whereClause . $orderClause;
    $stmt = $pdo->prepare($query);
    
    // Bind parameters if needed
    if ($filtroEstado && in_array($filtroEstado, ['pendiente', 'aprobada', 'rechazada'])) {
        $stmt->bindParam(':estado', $filtroEstado);
    }
    
    if (!empty($busqueda)) {
        $busquedaParam = "%$busqueda%";
        $stmt->bindParam(':busqueda', $busquedaParam);
    }
    
    // Forzar la carga completa de los datos
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    
    $stmt->execute();
    $permits = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Error al obtener datos: " . $e->getMessage());
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Permisos de Circulación</title>
    <!-- Actualizar favicon -->
    <link rel="icon" type="image/png" href="assets/images/Vertical (color) ISOLOGO MELIPILLA.png">
    <link rel="apple-touch-icon" href="assets/images/Vertical (color) ISOLOGO MELIPILLA.png">
    <!-- Resto de los enlaces CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/notificaciones.css">
    <!-- CSS de animaciones de bloqueo eliminado -->
    <style>
        .search-container {
            position: relative;
            margin-bottom: 15px;
        }
        .search-icon {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #6c757d;
            z-index: 10;
        }
        .search-input {
            padding-left: 35px;
            border-radius: 4px;
        }
        .filter-buttons {
            display: flex;
            justify-content: flex-end;
            gap: 5px;
            margin-bottom: 15px;
        }
        .filter-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
    </style>
</head>
<!-- Modificar la etiqueta body para incluir el ID de usuario -->
<body data-user-id="<?php echo $_SESSION['usuario_id']; ?>">
    <!-- Añadir barra de navegación con notificaciones -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <img src="imagenes/logo_blanco.png" alt="Logo Melipilla" class="navbar-logo">
            </a>
            <div class="ms-auto d-flex align-items-center">
                <!--<div class="notification-bell me-4">
                    <i class="bi bi-bell-fill"></i>
                    <span class="badge rounded-pill" id="contador-notificaciones"></span>
                </div>-->
                <a href="cerrar_sesion.php" class="btn btn-outline-light">
                    <i class="bi bi-box-arrow-right me-2"></i>
                    Cerrar sesión
                </a>
            </div>
        </div>
    </nav>

    <div class="container mt-4" id="main-container">
        <h1>Permisos de Circulación</h1>
        
        <?php if (!empty($statusMessage)): ?>
        <div class="alert <?php echo $statusClass; ?> alert-dismissible fade show" role="alert">
            <i class="bi <?php echo $statusClass == 'alert-success' ? 'bi-check-circle' : 'bi-exclamation-circle'; ?> me-2"></i>
            <?php echo $statusMessage; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        
        <div class="card">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <span>Listado de Permisos</span>
                <a href="includes/exportar_excel.php" class="btn btn-success btn-sm">
                    <i class="bi bi-file-excel me-1"></i> Exportar a Excel
                </a>
            </div>
            <div class="card-body">
                <!-- Agregar barra de búsqueda y filtros -->
                <div class="filter-row">
                    <div class="col-md-6">
                        <div class="search-container">
                            <i class="bi bi-search search-icon"></i>
                            <input type="text" id="searchInput" class="form-control search-input" placeholder="Buscar por patente, RUT o nombre..." value="<?php echo isset($_GET['busqueda']) ? htmlspecialchars($_GET['busqueda']) : ''; ?>">
                        </div>
                    </div>
                    <div class="filter-buttons">
                        <?php 
                        // Contar permisos por estado
                        $totalPermisos = count($permits);
                        $pendientes = 0;
                        $aprobados = 0;
                        $rechazados = 0;
                        
                        foreach ($permits as $p) {
                            $estado = strtolower($p['estado']);
                            if ($estado === 'pendiente') $pendientes++;
                            elseif ($estado === 'aprobada') $aprobados++;
                            elseif ($estado === 'rechazada') $rechazados++;
                        }
                        ?>
                        <button type="button" class="btn btn-secondary filter-btn" data-filter="">Todos (<?php echo $totalPermisos; ?>)</button>
                        <button type="button" class="btn btn-outline-warning filter-btn" data-filter="pendiente">Pendientes (<?php echo $pendientes; ?>)</button>
                        <button type="button" class="btn btn-outline-success filter-btn" data-filter="aprobada">Aprobados (<?php echo $aprobados; ?>)</button>
                        <button type="button" class="btn btn-outline-danger filter-btn" data-filter="rechazada">Rechazados (<?php echo $rechazados; ?>)</button>
                    </div>
                </div>
                
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Patente</th>
                                <th>RUT</th>
                                <th>Nombre</th>
                                <th>Estado</th>
                                <th>Fecha Solicitud</th>
                                <th>Fecha Actualización</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <!-- Modificar la sección de la tabla donde se muestran los permisos -->
                        <tbody>
                            <?php foreach ($permits as $permit): ?>
                                <tr>
                                    <td><?php echo $permit['vehiculo_id']; ?></td>
                                    <td><?php echo $permit['placa_patente']; ?></td>
                                    <td><?php echo $permit['rut']; ?></td>
                                    <td><?php echo $permit['nombre'] . ' ' . $permit['apellido_paterno'] . ' ' . $permit['apellido_materno']; ?></td>
                                    <td class="estado-cell">
                                        <?php if (strtolower($permit['estado']) === 'aprobada'): ?>
                                            <span class="badge bg-success">Aprobada</span>
                                        <?php elseif (strtolower($permit['estado']) === 'rechazada'): ?>
                                            <span class="badge bg-danger">Rechazada</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning">Pendiente</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo date('Y-m-d H:i:s', strtotime($permit['fecha_solicitud'])); ?></td>
                                    <td>
                                        <?php if (!empty($permit['fecha_actualizacion']) && $permit['fecha_actualizacion'] != $permit['fecha_solicitud']): ?>
                                            <?php 
                                                echo date('Y-m-d H:i:s', strtotime($permit['fecha_actualizacion']));
                                                // Calcular tiempo transcurrido
                                                $fecha1 = new DateTime($permit['fecha_solicitud']);
                                                $fecha2 = new DateTime($permit['fecha_actualizacion']);
                                                $intervalo = $fecha1->diff($fecha2);
                                                
                                                if ($intervalo->days > 0) {
                                                    echo '<br><small class="text-muted">(' . $intervalo->days . ' días)</small>';
                                                } else {
                                                    // Calcular total de minutos
                                                    $minutos_totales = ($intervalo->h * 60) + $intervalo->i;
                                                    
                                                    if ($minutos_totales >= 60) {
                                                        // Si es más de una hora, mostrar en formato horas
                                                        $horas = floor($minutos_totales / 60);
                                                        $minutos = $minutos_totales % 60;
                                                        
                                                        if ($minutos > 0) {
                                                            echo '<br><small class="text-muted">(' . $horas . ' hora' . ($horas > 1 ? 's' : '') . ' y ' . $minutos . ' min)</small>';
                                                        } else {
                                                            echo '<br><small class="text-muted">(' . $horas . ' hora' . ($horas > 1 ? 's' : '') . ')</small>';
                                                        }
                                                    } else {
                                                        // Si es menos de una hora, mostrar en minutos
                                                        echo '<br><small class="text-muted">(' . $minutos_totales . ' minutos)</small>';
                                                    }
                                                }
                                            ?>
                                        <?php else: ?>
                                            <span class="text-muted">Pendiente</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="action-cell">
                                        <?php if (!empty($permit['vehiculo_id'])): ?>
                                            <a href="ver_detalles.php?id=<?php echo $permit['vehiculo_id']; ?>" class="btn btn-info btn-sm">
                                                Ver Detalles
                                                <span class="visualizacion-badge" id="visualizacion-<?php echo $permit['vehiculo_id']; ?>"></span>
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- Al final del archivo, antes de cerrar el body -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/notificaciones.js"></script>
    <script src="assets/js/visualizaciones.js"></script>
    <!-- Agregar el nuevo script para actualización de estados en tiempo real -->
    <script src="assets/js/estado-tiempo-real.js"></script>
    
    <!-- Script para filtros y búsqueda en tiempo real -->
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Asignar data-id a las filas existentes
        document.querySelectorAll('tbody tr').forEach(tr => {
            const id = tr.querySelector('td:first-child').textContent.trim();
            tr.setAttribute('data-id', id);
        });

        // Variables para los filtros
        let currentFilter = '<?php echo isset($_GET["estado"]) ? $_GET["estado"] : ""; ?>';
        let searchTerm = '<?php echo isset($_GET["busqueda"]) ? htmlspecialchars($_GET["busqueda"]) : ""; ?>';
        
        // Función para aplicar filtros
        function applyFilters() {
            const rows = document.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                let showRow = true;
                
                // Filtrar por estado
                if (currentFilter) {
                    const estadoCell = row.querySelector('.estado-cell .badge');
                    const estado = estadoCell.textContent.toLowerCase();
                    
                    if (estado !== currentFilter) {
                        showRow = false;
                    }
                }
                
                // Filtrar por término de búsqueda
                if (searchTerm && showRow) {
                    const patente = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
                    const rut = row.querySelector('td:nth-child(3)').textContent.toLowerCase();
                    const nombre = row.querySelector('td:nth-child(4)').textContent.toLowerCase();
                    
                    if (!patente.includes(searchTerm.toLowerCase()) && 
                        !rut.includes(searchTerm.toLowerCase()) && 
                        !nombre.includes(searchTerm.toLowerCase())) {
                        showRow = false;
                    }
                }
                
                // Mostrar u ocultar fila
                row.style.display = showRow ? '' : 'none';
            });
        }
        
        // Manejar búsqueda en tiempo real
        const searchInput = document.getElementById('searchInput');
        searchInput.addEventListener('input', function() {
            searchTerm = this.value.trim();
            applyFilters();
        });
        
        // Manejar botones de filtro
        const filterButtons = document.querySelectorAll('.filter-btn');
        filterButtons.forEach(button => {
            // Establecer botón activo inicial
            if ((button.dataset.filter === currentFilter) || 
                (!button.dataset.filter && !currentFilter)) {
                button.classList.remove('btn-outline-secondary', 'btn-outline-warning', 'btn-outline-success', 'btn-outline-danger');
                
                if (!button.dataset.filter) {
                    button.classList.add('btn-secondary');
                } else if (button.dataset.filter === 'pendiente') {
                    button.classList.add('btn-warning');
                } else if (button.dataset.filter === 'aprobada') {
                    button.classList.add('btn-success');
                } else if (button.dataset.filter === 'rechazada') {
                    button.classList.add('btn-danger');
                }
            }
            
            // Manejar clic en botón
            button.addEventListener('click', function() {
                // Actualizar estado de los botones
                filterButtons.forEach(btn => {
                    btn.classList.remove('btn-secondary', 'btn-warning', 'btn-success', 'btn-danger');
                    
                    if (!btn.dataset.filter) {
                        btn.classList.add('btn-outline-secondary');
                    } else if (btn.dataset.filter === 'pendiente') {
                        btn.classList.add('btn-outline-warning');
                    } else if (btn.dataset.filter === 'aprobada') {
                        btn.classList.add('btn-outline-success');
                    } else if (btn.dataset.filter === 'rechazada') {
                        btn.classList.add('btn-outline-danger');
                    }
                });
                
                // Activar botón actual
                this.classList.remove('btn-outline-secondary', 'btn-outline-warning', 'btn-outline-success', 'btn-outline-danger');
                
                if (!this.dataset.filter) {
                    this.classList.add('btn-secondary');
                } else if (this.dataset.filter === 'pendiente') {
                    this.classList.add('btn-warning');
                } else if (this.dataset.filter === 'aprobada') {
                    this.classList.add('btn-success');
                } else if (this.dataset.filter === 'rechazada') {
                    this.classList.add('btn-danger');
                }
                
                // Actualizar filtro actual
                currentFilter = this.dataset.filter;
                applyFilters();
            });
        });
        
        // Aplicar filtros iniciales
        applyFilters();
        
        // Resto del código para actualización en tiempo real...
    });
    </script>

    <style>
    @keyframes highlightNew {
        0% { background-color: rgba(255, 255, 0, 0.2); }
        100% { background-color: transparent; }
    }
    
    @keyframes updateHighlight {
        0% { background-color: rgba(0, 255, 0, 0.3); }
        100% { background-color: transparent; }
    }
    </style>
</body>
</html>