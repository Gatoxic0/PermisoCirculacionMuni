<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Función para corregir rutas de archivos
function corregirRuta($ruta) {
    // Si la ruta contiene 'formulario/uploads', reemplazarla por la nueva ubicación
    $ruta = str_replace('formulario/uploads', 'uploads', $ruta);
    // También manejar rutas con barras invertidas (Windows)
    $ruta = str_replace('formulario\\uploads', 'uploads', $ruta);
    
    // Si la ruta es relativa y comienza con 'uploads/', añadir la URL base
    if (strpos($ruta, 'uploads/') === 0 || strpos($ruta, 'uploads\\') === 0) {
        // Obtener el protocolo y host actual
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
        $host = $_SERVER['HTTP_HOST'];
        
        // Construir URL completa
        $ruta = $protocol . $host . '/' . $ruta;
    }
    
    return $ruta;
}

session_start();
require_once 'config/config.php';

$id = $_GET['id'];

// Eliminada la verificación de bloqueos

// Fetch permit details
try {
    $query = "SELECT v.id as vehiculo_id, v.placa_patente, 
                     u.rut, u.nombre, u.apellido_paterno, u.apellido_materno, 
                     u.comuna, u.calle, u.numero, u.aclaratoria, u.telefono, u.email,
                     s.estado, s.fecha_solicitud
              FROM vehiculos v
              JOIN usuarios u ON v.usuario_id = u.id
              JOIN solicitudes s ON v.id = s.vehiculo_id
              WHERE v.id = :id";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $permit = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$permit) {
        header('Location: index.php');
        exit;
    }
    
    // Fetch documents
    $queryDocs = "SELECT * FROM documentos WHERE vehiculo_id = :vehiculo_id";
    $stmtDocs = $pdo->prepare($queryDocs);
    $stmtDocs->bindParam(':vehiculo_id', $permit['vehiculo_id']);
    $stmtDocs->execute();
    $documents = $stmtDocs->fetchAll(PDO::FETCH_ASSOC);
    
    // Organize documents by type
    $docs = [];
    foreach ($documents as $doc) {
        $docs[$doc['tipo_documento']] = $doc;
    }
    
} catch(PDOException $e) {
    die("Error al obtener datos: " . $e->getMessage());
}
// Process form submission (approve/reject)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        try {
            if ($_POST['action'] === 'approve') {
                // Update status to approved
                $updateQuery = "UPDATE solicitudes SET estado = 'aprobada', fecha_actualizacion = NOW() WHERE vehiculo_id = :vehiculo_id";
                $updateStmt = $pdo->prepare($updateQuery);
                $updateStmt->bindParam(':vehiculo_id', $permit['vehiculo_id']);
                $updateStmt->execute();
                
                // Obtener el usuario_id desde la tabla vehiculos
                $queryUsuario = "SELECT usuario_id FROM vehiculos WHERE id = :vehiculo_id";
                $stmtUsuario = $pdo->prepare($queryUsuario);
                $stmtUsuario->bindParam(':vehiculo_id', $permit['vehiculo_id']);
                $stmtUsuario->execute();
                $usuario = $stmtUsuario->fetch(PDO::FETCH_ASSOC);
                
                if ($usuario && isset($usuario['usuario_id'])) {
                    require_once 'includes/notificaciones.php';
                    $mensaje = "Su solicitud para el vehículo con patente {$permit['placa_patente']} ha sido aprobada.";
                    crearNotificacion($usuario['usuario_id'], $permit['vehiculo_id'], $mensaje, 'success');
                }
                
                // Enviar correo de aprobación
                if (!empty($permit['email'])) {
                    require_once 'includes/mail_sender.php';
                    $subject = "Aprobación de Solicitud de Traslado";
                    $htmlMessage = "Estimado/a {$permit['nombre']},<br><br>";
                    $htmlMessage .= "Sus documentos fueron aprobados existosamente por el departamento, ahora puede procedir a pagar en el siguiente link:<br><br>";
                    $htmlMessage .= "<a href='https://ww3.e-com.cl/Pagos/PermisoCirculacion/renovacion/ecomv3/vista/?id=88&plebcas=12&portal=%2707/03/2025%27&html=70&opc=1'>Realizar pago del permiso</a><br><br>";
                    $htmlMessage .= "Saludos cordiales,<br>";
                    $htmlMessage .= "Departamento de Permisos de Circulación<br>";
                    $htmlMessage .= "Municipalidad de Melipilla";
                    
                    if (enviarCorreoAprobacion($permit['email'], $subject, $htmlMessage)) {
                        // Email sent successfully
                        $_SESSION['alert'] = [
                            'type' => 'success',
                            'message' => 'La solicitud ha sido aprobada y se ha enviado el correo.'
                        ];
                    } else {
                        // Email failed to send
                        $_SESSION['alert'] = [
                            'type' => 'warning',
                            'message' => 'La solicitud ha sido aprobada pero hubo un problema al enviar el correo.'
                        ];
                    }
                }
                
                // Redirect to index without alert
                echo '<script>window.location.href = "index.php";</script>';
                exit;
            } elseif ($_POST['action'] === 'reject') {
                // Update status to rejected
                $updateQuery = "UPDATE solicitudes SET estado = 'rechazada', 
                               fecha_actualizacion = NOW(), 
                               comentarios = :comentarios 
                               WHERE vehiculo_id = :vehiculo_id";
                $updateStmt = $pdo->prepare($updateQuery);
                $updateStmt->bindParam(':vehiculo_id', $permit['vehiculo_id']);
                $updateStmt->bindParam(':comentarios', $_POST['email_message']);
                $updateStmt->execute();

                // Obtener el usuario_id desde la tabla vehiculos
                $queryUsuario = "SELECT usuario_id FROM vehiculos WHERE id = :vehiculo_id";
                $stmtUsuario = $pdo->prepare($queryUsuario);
                $stmtUsuario->bindParam(':vehiculo_id', $permit['vehiculo_id']);
                $stmtUsuario->execute();
                $usuario = $stmtUsuario->fetch(PDO::FETCH_ASSOC);
                
                if ($usuario && isset($usuario['usuario_id'])) {
                    require_once 'includes/notificaciones.php';
                    $mensaje = "Su solicitud para el vehículo con patente {$permit['placa_patente']} ha sido rechazada.";
                    crearNotificacion($usuario['usuario_id'], $permit['vehiculo_id'], $mensaje, 'danger');
                }

                // Enviar correo de rechazo
                // Send email
                if (!empty($permit['email'])) {  // Cambiar $_POST['email'] por $permit['email']
                    require_once 'includes/mail_sender.php';
                    $subject = "Rechazo de Solicitud de Permiso de Circulación";
                    $htmlMessage = nl2br($_POST['email_message']);
                    
                    // Usar $permit['email'] en lugar de $_POST['email']
                    if (enviarCorreo($permit['email'], $subject, $htmlMessage)) {
                        // Email sent successfully
                        $_SESSION['alert'] = [
                            'type' => 'success',
                            'message' => 'La solicitud ha sido rechazada y se ha enviado el correo.'
                        ];
                    } else {
                        // Email failed to send
                        $_SESSION['alert'] = [
                            'type' => 'warning',
                            'message' => 'La solicitud ha sido rechazada pero hubo un problema al enviar el correo.'
                        ];
                    }
                }
                echo '<script>window.location.href = "index.php";</script>';
                exit;
            }
        } catch(PDOException $e) {
            die("Error al actualizar estado: " . $e->getMessage());
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalles del Permiso de Circulación</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Agregar script para mostrar animación de carga durante redirecciones -->
    <style>
        #loading-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 9999;
            justify-content: center;
            align-items: center;
        }
        .spinner-container {
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            text-align: center;
        }
    </style>
    <script>
        // Mostrar animación de carga al enviar formularios
        document.addEventListener('DOMContentLoaded', function() {
            const forms = document.querySelectorAll('form');
            const loadingOverlay = document.getElementById('loading-overlay');
            
            forms.forEach(form => {
                form.addEventListener('submit', function() {
                    loadingOverlay.style.display = 'flex';
                });
            });
        });
    </script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/detalles.css">
    <link rel="stylesheet" href="assets/css/notificaciones.css">
    <!-- Eliminada la referencia a animaciones-bloqueo.css -->
</head>
<body>
    <!-- Añadir campo oculto con el ID del permiso para JavaScript -->
    <input type="hidden" id="permiso_id" value="<?php echo $permit['vehiculo_id']; ?>">
    
    <!-- Añadir barra de navegación con notificaciones -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <img src="imagenes/logo_blanco.png" alt="Logo Melipilla" class="navbar-logo">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="notificacionesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-bell-fill"></i>
                            <span class="badge rounded-pill bg-danger" id="contador-notificaciones" style="display: none;">0</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end notification-dropdown" id="notificaciones-dropdown" aria-labelledby="notificacionesDropdown">
                            <!-- Las notificaciones se cargarán aquí dinámicamente -->
                            <div class="dropdown-item text-center">Cargando notificaciones...</div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container mt-4">
        <h1>Detalles del Permiso de Circulación</h1>
        
        <?php if (isset($_SESSION['alert'])): ?>
        <div class="alert alert-<?php echo $_SESSION['alert']['type']; ?> alert-dismissible fade show" role="alert">
            <?php echo $_SESSION['alert']['message']; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php 
        // Limpiar la alerta después de mostrarla
        unset($_SESSION['alert']);
        endif; 
        ?>
        
        <div class="card">
            <div class="card-body">
                <!-- Información del solicitante -->
                <h2 class="section-title">Información del Solicitante</h2>
                <div class="row">
                    <div class="col-md-6">
                        <div class="field-label">RUT</div>
                        <div class="field-value"><?php echo $permit['rut']; ?></div>
                        
                        <div class="field-label">Nombre Completo</div>
                        <div class="field-value"><?php echo $permit['nombre'] . ' ' . $permit['apellido_paterno'] . ' ' . $permit['apellido_materno']; ?></div>
                        
                        <div class="field-label">Email</div>
                        <div class="field-value"><?php echo $permit['email']; ?></div>
                    </div>
                    <div class="col-md-6">
                        <div class="field-label">Teléfono</div>
                        <div class="field-value"><?php echo $permit['telefono']; ?></div>
                        
                        <div class="field-label">Dirección</div>
                        <div class="field-value">
                            <?php echo $permit['calle'] . ' ' . $permit['numero'] . ', ' . $permit['comuna']; ?>
                            <?php if (!empty($permit['aclaratoria'])): ?>
                                <br><small><?php echo $permit['aclaratoria']; ?></small>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Información del vehículo -->
                <h2 class="section-title mt-4">Información del Vehículo</h2>
                <div class="row">
                    <div class="col-md-6">
                        <div class="field-label">Placa Patente</div>
                        <div class="field-value"><?php echo $permit['placa_patente']; ?></div>
                    </div>
                    <div class="col-md-6">
                        <div class="field-label">Estado de la Solicitud</div>
                        <div class="field-value">
                            <?php 
                            $badgeClass = '';
                            switch($permit['estado']) {
                                case 'aprobada':
                                    $badgeClass = 'bg-success';
                                    break;
                                case 'rechazada':
                                    $badgeClass = 'bg-danger';
                                    break;
                                default:
                                    $badgeClass = 'bg-warning text-dark';
                            }
                            ?>
                            <span class="badge <?php echo $badgeClass; ?>">
                                <?php echo ucfirst($permit['estado']); ?>
                            </span>
                        </div>
                        
                        <div class="field-label">Fecha de Solicitud</div>
                        <div class="field-value"><?php echo date('d/m/Y H:i', strtotime($permit['fecha_solicitud'])); ?></div>
                    </div>
                </div>
                
                <!-- Documentos -->
                <h2 class="section-title mt-4">Documentos</h2>
                
                <!-- Eliminar este bloque de depuración -->
                <!-- <div class="alert alert-info">
                    <h5>Información de depuración:</h5>
                    <p>Tipos de documentos cargados:</p>
                    <pre><?php print_r(array_keys($docs)); ?></pre>
                </div> -->
                
                <!-- First row of documents -->
                <div class="row document-row">
                    <div class="col-md-6">
                        <div class="document-card">
                            <h3 class="document-title">Permiso de Circulación año anterior</h3>
                            <div class="document-actions">
                                <?php if (isset($docs['permiso_circulacion_a'])): ?>
                                    <a href="<?php echo corregirRuta($docs['permiso_circulacion_a']['ruta_archivo']); ?>" class="btn btn-primary btn-sm" target="_blank">
                                        <i class="bi bi-eye"></i> Ver
                                    </a>
                                    <?php if ($permit['estado'] === 'rechazada'): ?>
                                        <button type="button" class="btn btn-warning btn-sm ms-2" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#updateDocModal" 
                                                data-doc-type="permiso_circulacion_a"
                                                data-doc-name="Permiso de Circulación año anterior">
                                            <i class="bi bi-upload"></i> Actualizar
                                        </button>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="text-muted">No disponible</span>
                                    <?php if ($permit['estado'] === 'rechazada'): ?>
                                        <button type="button" class="btn btn-warning btn-sm ms-2" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#updateDocModal" 
                                                data-doc-type="permiso_circulacion_a"
                                                data-doc-name="Permiso de Circulación año anterior">
                                            <i class="bi bi-upload"></i> Subir
                                        </button>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <!-- Corregir la sección donde se muestra el certificado de homologación -->
                    <div class="col-md-6">
                        <div class="document-card">
                            <h3 class="document-title">Certificado de Homologación o Revision Tecnica y analisis de gases</h3>
                            <div class="document-actions">
                                <?php if (isset($docs['certificado_homologacion'])): ?>
                                    <!-- Corregir la ruta del documento - estaba usando permiso_circulacion_a en lugar de certificado_homologacion -->
                                    <a href="<?php echo corregirRuta($docs['certificado_homologacion']['ruta_archivo']); ?>?t=<?php echo time(); ?>" class="btn btn-primary btn-sm" target="_blank">
                                        <i class="bi bi-eye"></i> Ver
                                    </a>
                                    <?php if ($permit['estado'] === 'rechazada'): ?>
                                        <button type="button" class="btn btn-warning btn-sm ms-2" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#updateDocModal" 
                                                data-doc-type="certificado_homologacion"
                                                data-doc-name="Certificado de Homologación">
                                            <i class="bi bi-upload"></i> Actualizar
                                        </button>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="text-muted">No disponible</span>
                                    <?php if ($permit['estado'] === 'rechazada'): ?>
                                        <button type="button" class="btn btn-warning btn-sm ms-2" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#updateDocModal" 
                                                data-doc-type="certificado_homologacion"
                                                data-doc-name="Certificado de Homologación">
                                            <i class="bi bi-upload"></i> Subir
                                        </button>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Second row of documents -->
                <div class="row document-row">
                    <div class="col-md-6">
                        <div class="document-card">
                            <h3 class="document-title">Seguro obligatorio (con vencimiento el 31 de marzo de 2026)</h3>
                            <div class="document-actions">
                                <?php if (isset($docs['certificado_inscripcion_a']) || isset($docs['seguro_obligatorio'])): ?>
                                    <?php 
                                        $docKey = isset($docs['seguro_obligatorio']) ? 'seguro_obligatorio' : 'certificado_inscripcion_a';
                                    ?>
                                    <a href="<?php echo corregirRuta($docs[$docKey]['ruta_archivo']); ?>" class="btn btn-primary btn-sm" target="_blank">
                                        <i class="bi bi-eye"></i> Ver
                                    </a>
                                    <?php if ($permit['estado'] === 'rechazada'): ?>
                                        <button type="button" class="btn btn-warning btn-sm ms-2" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#updateDocModal" 
                                                data-doc-type="seguro_obligatorio"
                                                data-doc-name="Seguro obligatorio">
                                            <i class="bi bi-upload"></i> Actualizar
                                        </button>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="text-muted">No disponible</span>
                                    <?php if ($permit['estado'] === 'rechazada'): ?>
                                        <button type="button" class="btn btn-warning btn-sm ms-2" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#updateDocModal" 
                                                data-doc-type="seguro_obligatorio"
                                                data-doc-name="Seguro obligatorio">
                                            <i class="bi bi-upload"></i> Subir
                                        </button>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="document-card">
                            <h3 class="document-title">Certificado de Inscripción</h3>
                            <div class="document-actions">
                                <?php if (isset($docs['certificado_inscripcion']) || isset($docs['certificado_inscripcion_b'])): ?>
                                    <?php 
                                        $docKey = isset($docs['certificado_inscripcion']) ? 'certificado_inscripcion' : 'certificado_inscripcion_b';
                                    ?>
                                    <a href="<?php echo corregirRuta($docs[$docKey]['ruta_archivo']); ?>" class="btn btn-primary btn-sm" target="_blank">
                                        <i class="bi bi-eye"></i> Ver
                                    </a>
                                    <?php if ($permit['estado'] === 'rechazada'): ?>
                                        <button type="button" class="btn btn-warning btn-sm ms-2" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#updateDocModal" 
                                                data-doc-type="certificado_inscripcion"
                                                data-doc-name="Certificado de Inscripción">
                                            <i class="bi bi-upload"></i> Actualizar
                                        </button>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="text-muted">No disponible</span>
                                    <?php if ($permit['estado'] === 'rechazada'): ?>
                                        <button type="button" class="btn btn-warning btn-sm ms-2" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#updateDocModal" 
                                                data-doc-type="certificado_inscripcion"
                                                data-doc-name="Certificado de Inscripción">
                                            <i class="bi bi-upload"></i> Subir
                                        </button>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Third row of documents -->
                <div class="row document-row">
                    <div class="col-md-6">
                        <div class="document-card">
                            <h3 class="document-title">Factura (solo para vehículos del año 2025)</h3>
                            <div class="document-actions">
                                <?php if (isset($docs['factura'])): ?>
                                    <a href="<?php echo corregirRuta($docs['factura']['ruta_archivo']); ?>" class="btn btn-primary btn-sm" target="_blank">
                                        <i class="bi bi-eye"></i> Ver
                                    </a>
                                    <?php if ($permit['estado'] === 'rechazada'): ?>
                                        <button type="button" class="btn btn-warning btn-sm ms-2" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#updateDocModal" 
                                                data-doc-type="factura"
                                                data-doc-name="Factura">
                                            <i class="bi bi-upload"></i> Actualizar
                                        </button>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="text-muted">No disponible</span>
                                    <?php if ($permit['estado'] === 'rechazada'): ?>
                                        <button type="button" class="btn btn-warning btn-sm ms-2" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#updateDocModal" 
                                                data-doc-type="factura"
                                                data-doc-name="Factura">
                                            <i class="bi bi-upload"></i> Subir
                                        </button>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Botones de acción -->
                <?php if ($permit['estado'] === 'pendiente'): ?>
                <div class="action-buttons">
                    <form method="POST" class="d-inline">
                        <input type="hidden" name="action" value="approve">
                        <button type="submit" class="btn btn-success">
                            <i class="bi bi-check-circle"></i> Aprobar
                        </button>
                    </form>
                    <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#rejectModal">
                        <i class="bi bi-x-circle"></i> Rechazar
                    </button>
                </div>
                <?php elseif ($permit['estado'] === 'rechazada'): ?>
                <div class="action-buttons">
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle"></i> Actualice los documentos necesarios y luego apruebe la solicitud.
                    </div>
                    <form method="POST" class="d-inline">
                        <input type="hidden" name="action" value="approve">
                        <button type="submit" class="btn btn-success">
                            <i class="bi bi-check-circle"></i> Aprobar con documentos actualizados
                        </button>
                    </form>
                </div>
                <?php endif; ?>
                
                <!-- Al final del contenido, antes de cerrar card-body -->
                <div class="mt-4">
                    <a href="index.php" class="btn btn-primary volver-al-listado">
                        <i class="bi bi-arrow-left"></i> Volver al listado
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Modal de Rechazo -->
    <div class="modal fade" id="rejectModal" tabindex="-1" aria-labelledby="rejectModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="rejectModalLabel">Rechazar Permiso</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="rejectForm" method="post">
                        <input type="hidden" name="action" value="reject">
                        
                        <div class="mb-3">
                            <label for="email" class="form-label">Correo del solicitante:</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo isset($permit['email']) ? $permit['email'] : ''; ?>" readonly>
                        </div>
                        
                        <div class="mb-3">
                            <label for="email_message" class="form-label">Mensaje de rechazo:</label>
                            <textarea class="form-control" id="email_message" name="email_message" rows="6" required>Estimado/a <?php 
                            $nombre = '';
                            if (isset($permit['nombre'])) {
                                $nombre = $permit['nombre'];
                            } elseif (isset($permit['name'])) {
                                $nombre = $permit['name'];
                            }
                            echo $nombre;
                            ?>,

Lamentamos informarle que su solicitud de permiso de circulación para el vehículo con placa <?php 
echo isset($permit['placa_patente']) ? $permit['placa_patente'] : (isset($permit['plate']) ? $permit['plate'] : ''); 
?> ha sido rechazada.

Motivo del rechazo:
[Por favor, indique aquí el motivo específico del rechazo]

Si tiene alguna pregunta, no dude en contactarnos.

Saludos cordiales,
Departamento de Permisos de Circulación</textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-danger" id="confirmReject">Rechazar y Enviar Correo</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de Actualización de Documentos -->
    <div class="modal fade" id="updateDocModal" tabindex="-1" aria-labelledby="updateDocModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="updateDocModalLabel">Actualizar Documento</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="includes/actualizar_documento.php" enctype="multipart/form-data" class="update-doc-form">
                        <input type="hidden" name="vehiculo_id" value="<?php echo $permit['vehiculo_id']; ?>">
                        <input type="hidden" name="tipo_documento" id="tipo_documento" value="">
                        
                        <div class="mb-3">
                            <label for="documento" class="form-label">Seleccione el nuevo documento:</label>
                            <input type="file" class="form-control" id="documento" name="documento" required>
                            <div class="form-text">Formatos permitidos: PDF, JPG, PNG (máx. 5MB)</div>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">Actualizar documento</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Script para manejar la actualización de documentos -->
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Mapeo de nombres de documentos para la interfaz
        const documentLabels = {
            'permiso_circulacion_a': 'Permiso de Circulación',
            'certificado_homologacion': 'Certificado de Homologación',
            'certificado_inscripcion_a': 'Seguro Obligatorio',
            'certificado_inscripcion_b': 'Certificado de Inscripción',
            'factura': 'Factura'
        };
        
        // Configurar el modal de actualización de documentos
        const updateDocModal = document.getElementById('updateDocModal');
        if (updateDocModal) {
            updateDocModal.addEventListener('show.bs.modal', function(event) {
                const button = event.relatedTarget;
                const docType = button.getAttribute('data-doc-type');
                const docName = button.getAttribute('data-doc-name') || documentLabels[docType] || docType;
                
                // Actualizar el título del modal y el campo oculto
                document.getElementById('updateDocModalLabel').textContent = 'Actualizar: ' + docName;
                document.getElementById('tipo_documento').value = docType;
            });
        }
    });
    </script>
    
    <!-- Añadir este código al final del archivo, antes de </body> -->
    <!-- Modificar el código JavaScript para ocultar la pantalla de carga después de completar la operación -->
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Capturar el envío del formulario de actualización
        const updateForms = document.querySelectorAll('.update-doc-form');
        const loadingOverlay = document.getElementById('loading-overlay');
        
        updateForms.forEach(form => {
            form.addEventListener('submit', function(e) {
                e.preventDefault(); // Evitar el envío tradicional del formulario
                
                // Mostrar overlay de carga
                if (loadingOverlay) {
                    loadingOverlay.style.display = 'flex';
                }
                
                const formData = new FormData(this);
                const submitBtn = this.querySelector('button[type="submit"]');
                const originalBtnText = submitBtn.innerHTML;
                
                // Cambiar el texto del botón para indicar que está procesando
                submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Procesando...';
                submitBtn.disabled = true;
                
                // Enviar los datos mediante AJAX
                fetch('includes/actualizar_documento.php', {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Error en la respuesta del servidor');
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('Respuesta del servidor:', data);
                    
                    // Ocultar overlay de carga
                    if (loadingOverlay) {
                        loadingOverlay.style.display = 'none';
                    }
                    
                    // Mostrar alerta de éxito
                    alert('Documento actualizado correctamente.');
                    
                    // Cerrar el modal
                    const modal = bootstrap.Modal.getInstance(document.getElementById('updateDocModal'));
                    if (modal) {
                        modal.hide();
                    }
                    
                    // Actualizar el botón del documento para mostrar que está disponible
                    const docType = document.getElementById('tipo_documento').value;
                    const docButtons = document.querySelectorAll(`[data-doc-type="${docType}"]`);
                    
                    docButtons.forEach(button => {
                        const cardActions = button.closest('.document-actions');
                        if (cardActions) {
                            // Construir la URL correcta sin 'formulario/'
                            const baseUrl = window.location.protocol + '//' + window.location.host;
                            const docUrl = baseUrl + '/' + data.ruta_archivo + '?t=' + Date.now();
                            
                            // Actualizar la interfaz para mostrar que el documento está disponible
                            cardActions.innerHTML = `
                                <a href="${docUrl}" class="btn btn-primary btn-sm" target="_blank">
                                    <i class="bi bi-eye"></i> Ver
                                </a>
                                <button type="button" class="btn btn-warning btn-sm ms-2" 
                                        data-bs-toggle="modal" 
                                        data-bs-target="#updateDocModal" 
                                        data-doc-type="${docType}"
                                        data-doc-name="${button.getAttribute('data-doc-name')}">
                                    <i class="bi bi-upload"></i> Actualizar
                                </button>
                            `;
                        }
                    });
                    
                    // Restaurar el botón de envío
                    submitBtn.innerHTML = originalBtnText;
                    submitBtn.disabled = false;
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error al actualizar el documento. Por favor, inténtelo de nuevo.');
                    
                    // Ocultar overlay de carga en caso de error también
                    if (loadingOverlay) {
                        loadingOverlay.style.display = 'none';
                    }
                    
                    // Restaurar el botón
                    submitBtn.innerHTML = originalBtnText;
                    submitBtn.disabled = false;
                });
            });
        });
    });
    </script>
   
    <!-- Agregar overlay de carga -->
    <div id="loading-overlay">
        <div class="spinner-container">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Cargando...</span>
            </div>
            <p class="mt-2">Procesando solicitud...</p>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/notificaciones.js"></script>
    
    <!-- Script para manejar el formulario de rechazo -->
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Manejar el botón de confirmación de rechazo
        document.getElementById('confirmReject').addEventListener('click', function() {
            document.getElementById('rejectForm').submit();
        });
        // Sistema de visualización de permisos
        const permisoId = document.getElementById('permiso_id').value;
        // Registrar que el usuario está viendo este permiso
        fetch('includes/registrar_visualizacion.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                permiso_id: permisoId,
                accion: 'iniciar'
            })
        });
        // Registrar que el usuario dejó de ver el permiso cuando cierra la página
        window.addEventListener('beforeunload', function() {
            navigator.sendBeacon('includes/registrar_visualizacion.php', JSON.stringify({
                permiso_id: permisoId,
                accion: 'finalizar'
            }));
        });
    });
    </script>
</body>
</html>