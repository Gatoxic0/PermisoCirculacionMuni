<?php
require_once 'config/config.php';
$mensaje = '';

// Solo mostrar mensajes si viene de un POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        // Verificar si la placa patente ya existe en la base de datos
        $checkPlaca = "SELECT COUNT(*) FROM vehiculos WHERE placa_patente = :placa_patente";
        $stmtCheck = $pdo->prepare($checkPlaca);
        $stmtCheck->bindParam(':placa_patente', $_POST['placa_patente']);
        $stmtCheck->execute();
        
        if ($stmtCheck->fetchColumn() > 0) {
            // La placa patente ya existe, mostrar mensaje de error
            $mensaje = '<div class="alert alert-error">
                            <i class="fas fa-exclamation-triangle"></i>
                            <h3>¡Error al procesar su solicitud!</h3>
                            <p>La placa patente ingresada ya existe en nuestro sistema. Por favor verifique la información.</p>
                        </div>';
        } else {
            // Iniciar transacción
            $pdo->beginTransaction();
            
            // Verificar si el usuario ya existe por RUT o por EMAIL
            $checkUsuario = "SELECT id FROM usuarios WHERE rut = :rut OR email = :email";
            $stmtCheckUsuario = $pdo->prepare($checkUsuario);
            $stmtCheckUsuario->bindParam(':rut', $_POST['rut']);
            $stmtCheckUsuario->bindParam(':email', $_POST['email']);
            $stmtCheckUsuario->execute();
            $usuarioExistente = $stmtCheckUsuario->fetch(PDO::FETCH_ASSOC);
            
            if ($usuarioExistente) {
                // Si el usuario ya existe, actualizar sus datos
                $sqlUsuario = "UPDATE usuarios SET 
                               nombre = :nombre, 
                               apellido_paterno = :apellido_paterno, 
                               apellido_materno = :apellido_materno, 
                               comuna = :comuna, 
                               calle = :calle, 
                               numero = :numero, 
                               aclaratoria = :aclaratoria, 
                               telefono = :telefono
                               WHERE id = :id";
                
                $stmtUsuario = $pdo->prepare($sqlUsuario);
                $stmtUsuario->bindParam(':id', $usuarioExistente['id']);
                $stmtUsuario->bindParam(':nombre', $_POST['nombre']);
                $stmtUsuario->bindParam(':apellido_paterno', $_POST['apellido_paterno']);
                $stmtUsuario->bindParam(':apellido_materno', $_POST['apellido_materno']);
                $stmtUsuario->bindParam(':comuna', $_POST['comuna']);
                $stmtUsuario->bindParam(':calle', $_POST['calle']);
                $stmtUsuario->bindParam(':numero', $_POST['numero']);
                $stmtUsuario->bindParam(':aclaratoria', $_POST['aclaratoria']);
                $stmtUsuario->bindParam(':telefono', $_POST['telefono']);
                $stmtUsuario->execute();
                
                $usuario_id = $usuarioExistente['id'];
            } else {
                // Si el usuario no existe, insertarlo
                $sqlUsuario = "INSERT INTO usuarios (rut, nombre, apellido_paterno, apellido_materno, comuna, calle, numero, aclaratoria, telefono, email) 
                              VALUES (:rut, :nombre, :apellido_paterno, :apellido_materno, :comuna, :calle, :numero, :aclaratoria, :telefono, :email)";
                
                $stmtUsuario = $pdo->prepare($sqlUsuario);
                $stmtUsuario->bindParam(':rut', $_POST['rut']);
                $stmtUsuario->bindParam(':nombre', $_POST['nombre']);
                $stmtUsuario->bindParam(':apellido_paterno', $_POST['apellido_paterno']);
                $stmtUsuario->bindParam(':apellido_materno', $_POST['apellido_materno']);
                $stmtUsuario->bindParam(':comuna', $_POST['comuna']);
                $stmtUsuario->bindParam(':calle', $_POST['calle']);
                $stmtUsuario->bindParam(':numero', $_POST['numero']);
                $stmtUsuario->bindParam(':aclaratoria', $_POST['aclaratoria']);
                $stmtUsuario->bindParam(':telefono', $_POST['telefono']);
                $stmtUsuario->bindParam(':email', $_POST['email']);
                $stmtUsuario->execute();
                
                $usuario_id = $pdo->lastInsertId();
            }
            
            // 2. Insertar en la tabla vehículos
            $sqlVehiculo = "INSERT INTO vehiculos (placa_patente, usuario_id) VALUES (:placa_patente, :usuario_id)";
            $stmtVehiculo = $pdo->prepare($sqlVehiculo);
            $stmtVehiculo->bindParam(':placa_patente', $_POST['placa_patente']);
            $stmtVehiculo->bindParam(':usuario_id', $usuario_id);
            $stmtVehiculo->execute();
            
            $vehiculo_id = $pdo->lastInsertId();
            
            // 3. Insertar en la tabla solicitudes
            $sqlSolicitud = "INSERT INTO solicitudes (vehiculo_id, estado) VALUES (:vehiculo_id, 'pendiente')";
            $stmtSolicitud = $pdo->prepare($sqlSolicitud);
            $stmtSolicitud->bindParam(':vehiculo_id', $vehiculo_id);
            $stmtSolicitud->execute();
            
            // El resto del código permanece igual...
            
            // 4. Procesar y subir documentos
            $uploadDir = 'uploads/';
            
            // Crear directorio si no existe
            if (!file_exists($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }
            
            $documentTypes = [
                'permiso_circulacion_a',
                'permiso_circulacion_b',
                'certificado_homologacion',
                'factura',
                'certificado_inscripcion_a',
                'certificado_inscripcion_b'
            ];
            
            foreach ($documentTypes as $docType) {
                if (isset($_FILES[$docType]) && $_FILES[$docType]['error'] == 0) {
                    $fileName = $_FILES[$docType]['name'];
                    $tmpName = $_FILES[$docType]['tmp_name'];
                    $fileNameNew = uniqid() . '_' . $fileName;
                    $fileDestination = $uploadDir . $fileNameNew;
                    
                    if (move_uploaded_file($tmpName, $fileDestination)) {
                        // Insertar información del documento en la tabla documentos
                        $sqlDocumento = "INSERT INTO documentos (vehiculo_id, tipo_documento, nombre_archivo, ruta_archivo) 
                                        VALUES (:vehiculo_id, :tipo_documento, :nombre_archivo, :ruta_archivo)";
                        $stmtDocumento = $pdo->prepare($sqlDocumento);
                        $stmtDocumento->bindParam(':vehiculo_id', $vehiculo_id);
                        $stmtDocumento->bindParam(':tipo_documento', $docType);
                        $stmtDocumento->bindParam(':nombre_archivo', $fileName);
                        $stmtDocumento->bindParam(':ruta_archivo', $fileDestination);
                        $stmtDocumento->execute();
                    }
                }
            }
            
            // Confirmar transacción
            $pdo->commit();
            
            // Mensaje de éxito con estilo llamativo
            $mensaje = '<div class="alert alert-success">
                            <i class="fas fa-check-circle"></i>
                            <h3>¡Formulario enviado exitosamente!</h3>
                            <p>Su solicitud ha sido recibida y está en proceso de revisión.</p>
                        </div>';
            
            // Limpiar el formulario después de enviar
            $_POST = array();
        }
    } catch(PDOException $e) {
        // Revertir transacción en caso de error
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $mensaje = '<div class="alert alert-error">
                        <i class="fas fa-exclamation-triangle"></i>
                        <h3>¡Error al procesar su solicitud!</h3>
                        <p>Detalles: ' . $e->getMessage() . '</p>
                    </div>';
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Solicitud de Renovación Permisos de Circulación Otras Comunas</title>
    <link rel="stylesheet" href="formulario.css">
    <link rel="icon" type="image/png" href="imagenes/icono_web.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Script de Microsoft Clarity para mapa de calor -->
    <script type="text/javascript">
    (function(c,l,a,r,i,t,y){
        c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
        t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
        y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
    })(window, document, "clarity", "script", "qo4ft3zpwa");
    </script>
    <!-- Agregar fuente Roboto de Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <!-- Agregar jQuery UI para autocompletado -->
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
    <style>
        /* Estilos para las alertas llamativas */
        .alert {
            padding: 20px;
            margin: 20px 0;
            border-radius: 8px;
            text-align: center;
            animation: fadeIn 0.5s ease-in-out;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 2px solid #c3e6cb;
        }
        
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 2px solid #f5c6cb;
        }
        
        .alert i {
            font-size: 48px;
            margin-bottom: 10px;
        }
        
        .alert h3 {
            margin: 10px 0;
            font-size: 22px;
        }
        
        /* Estilo para el icono de cabecera - MODIFICADO */
        .header-icon {
            width: 180px; /* Reducido para mejor proporción */
            height: auto;
            margin-bottom: 15px; /* Espacio entre logo y título */
            display: block;
            margin-left: auto;
            margin-right: auto;
            margin-top: 0; /* Eliminado el margen negativo */
            position: relative;
            z-index: 2;
        }
        
        /* Modificación de colores del encabezado */
        .form-header {
            background-color: #0F0758;
            padding: 40px 30px; /* Ajustado el padding vertical */
            position: relative;
        }
        
        /* Asegurar que los títulos de sección mantengan el color azul */
        .form-section h2, .form-section h2 i {
            color: #0F0758 !important;
        }
        
        /* Color de texto general - ACTUALIZADO A NEGRO, TAMAÑO 16px Y NEGRITA */
        body, p, label, input, select, .form-group label, .campos-obligatorios, .formato-info p {
            color: #000000;
            font-size: 16px;
            font-weight: bold !important;
        }
        
        /* Mantener color original para placeholders y sin negrita */
        input::placeholder, select::placeholder, textarea::placeholder {
            color: #8B8B8B !important;
            font-size: 16px;
            font-weight: normal !important;
        }
        
        /* Mantener color blanco para el botón de enviar */
        .submit-button {
            color: #fff !important;
            font-weight: normal !important;
        }

        .form-section h2 i {
            color: #0F0758;
        }

        .file-upload label, .no-file-selected, .file-selected, .examinar-button {
        font-size: 16px !important;
        }

        body {
            background-attachment: fixed;
        }
        
        /* Mejorar contraste del contenedor sobre el fondo */
        .container {
            background-color: rgba(255, 255, 255, 0.95);
        }
        
        /* Formato info en la sección de documentos */
        .formato-info p {
            font-size: 16px !important;
            color: #000000 !important;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-header">
            <img src="imagenes/logo_blanco.png" alt="Icono formulario" class="header-icon">
            <h1>Solicitud de Traslado Permisos de Circulación Otras Comunas</h1>
            <p>Complete el formulario con los datos solicitados</p>
        </div>

        <?php echo $mensaje; ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" enctype="multipart/form-data">
            <div class="form-section datos-personales">
                <h2><i class="fas fa-user-circle"></i> Datos Personales</h2>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="rut">RUT</label>
                        <input type="text" id="rut" name="rut" placeholder="11.111.111-1" required>
                    </div>
                    <div class="form-group">
                        <label for="placa_patente">Placa Patente</label>
                        <input type="text" id="placa_patente" name="placa_patente" placeholder="ABCD34" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="nombre">Nombre</label>
                        <input type="text" id="nombre" name="nombre" required>
                    </div>
                    <div class="form-group">
                        <label for="apellido_paterno">Apellido Paterno</label>
                        <input type="text" id="apellido_paterno" name="apellido_paterno" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="apellido_materno">Apellido Materno</label>
                        <input type="text" id="apellido_materno" name="apellido_materno" required>
                    </div>
                    <div class="form-group">
                        <label for="comuna">Comuna</label>
                        <input type="text" id="comuna" name="comuna" class="comuna-autocomplete" placeholder="Escriba para buscar comuna" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="calle">Calle</label>
                        <input type="text" id="calle" name="calle" required>
                    </div>
                    <div class="form-group">
                        <label for="numero">Número</label>
                        <input type="text" id="numero" name="numero" required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="aclaratoria">Complemento (Block, Depto, Etc.)</label>
                    <input type="text" id="aclaratoria" name="aclaratoria">
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="telefono">Teléfono</label>
                        <div class="telefono-container">
                            <span class="prefix">+56</span>
                            <input type="tel" id="telefono" name="telefono" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="email">Email *</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="confirmar_email">Confirmar Email</label>
                    <input type="email" id="confirmar_email" name="confirmar_email" required>
                </div>
            </div>

            <div class="form-section adjuntar-documentacion">
                <h2><i class="fas fa-file-upload"></i> Adjuntar Documentación</h2>
                
                <div class="formato-info">
                    <p><i class="fas fa-info-circle"></i> Formatos permitidos: PDF - JPG - DOC - DOCX</p>
                    <p><i class="fas fa-exclamation-circle"></i>Tamaño máximo TOTAL de los archivos: 5 megabytes (MB)</p>
                    <p><i class="fas fa-exclamation-triangle" style="color: #dc3545;"></i> Los campos marcados con <span style="color: #dc3545;">*</span> son obligatorios</p>
                </div>
                <div class="file-upload">
                    <label>Permiso de circulación año anterior <span style="color: #dc3545;">*</span></label>
                    <button type="button" class="examinar-button">
                        <i class="fas fa-folder-open"></i> Examinar...
                    </button>
                    <span class="no-file-selected">No se ha seleccionado ningún archivo</span>
                    <input type="file" name="permiso_circulacion_a" required style="display:none">
                </div>
                <div class="file-upload">
                    <label>Certificado de homologación o revisión técnica y análisis de gases (Debe estar vigente) <span style="color: #dc3545;">*</span></label>
                    <button type="button" class="examinar-button">
                        <i class="fas fa-folder-open"></i> Examinar...
                    </button>
                    <span class="no-file-selected">No se ha seleccionado ningún archivo</span>
                    <input type="file" name="certificado_homologacion" required style="display:none">
                </div>

                <div class="file-upload">
                    <label>Seguro obligatorio (con vencimiento el 31 de marzo de 2026) <span style="color: #dc3545;">*</span></label>
                    <button type="button" class="examinar-button">
                        <i class="fas fa-folder-open"></i> Examinar...
                    </button>
                    <span class="no-file-selected">No se ha seleccionado ningún archivo</span>
                    <input type="file" name="certificado_inscripcion_a" required style="display:none">
                </div>

                <div class="file-upload">
                    <label>Certificado de inscripción</label>
                    <button type="button" class="examinar-button">
                        <i class="fas fa-folder-open"></i> Examinar...
                    </button>
                    <span class="no-file-selected">No se ha seleccionado ningún archivo</span>
                    <input type="file" name="certificado_inscripcion_b" style="display:none">
                </div>
                
                <div class="file-upload">
                    <label>Factura (solo para vehículos del año 2025)</label>
                    <button type="button" class="examinar-button">
                        <i class="fas fa-folder-open"></i> Examinar...
                    </button>
                    <span class="no-file-selected">No se ha seleccionado ningún archivo</span>
                    <input type="file" name="factura" style="display:none">
                </div>
            </div>

            <button type="submit" class="submit-button">Enviar Solicitud</button>
        </form>

        <footer>
            <p>© 2025 Municipalidad de Melipilla. Todos los derechos reservados.</p>
        </footer>
    </div>

    <script>
        document.querySelectorAll('.examinar-button').forEach(button => {
            button.addEventListener('click', () => {
                const fileInput = button.parentElement.querySelector('input[type="file"]');
                fileInput.click();
            });
        });

        document.querySelectorAll('input[type="file"]').forEach(input => {
            input.addEventListener('change', function() {
                const span = this.parentElement.querySelector('.no-file-selected');
                if (this.files[0]) {
                    const fileName = this.files[0].name;
                    span.textContent = fileName;
                    span.classList.add('file-selected');
                    // Cambiar el icono del botón a check
                    const buttonIcon = this.parentElement.querySelector('.examinar-button i');
                    buttonIcon.className = 'fas fa-check';
                } else {
                    span.textContent = 'No se ha seleccionado ningún archivo';
                    span.classList.remove('file-selected');
                    // Restaurar el icono original
                    const buttonIcon = this.parentElement.querySelector('.examinar-button i');
                    buttonIcon.className = 'fas fa-folder-open';
                }
            });
        });

        document.getElementById('confirmar_email').addEventListener('input', function() {
            const email = document.getElementById('email').value;
            if (this.value !== email) {
                this.setCustomValidity('Los correos electrónicos no coinciden');
            } else {
                this.setCustomValidity('');
            }
        });

        // Validación y formateo del RUT chileno en tiempo real
        document.getElementById('rut').addEventListener('input', function() {
            // Eliminar caracteres no deseados (solo permitir números y K)
            let rutValue = this.value.replace(/[^\dkK]/g, '');
            
            // Separar cuerpo y dígito verificador si hay suficientes caracteres
            if (rutValue.length > 1) {
                const dv = rutValue.slice(-1).toUpperCase();
                const cuerpo = rutValue.slice(0, -1);
                
                // Formatear el cuerpo con puntos
                let rutFormateado = '';
                let i = cuerpo.length;
                while (i > 0) {
                    const inicio = Math.max(0, i - 3);
                    rutFormateado = cuerpo.substring(inicio, i) + (rutFormateado ? '.' + rutFormateado : '');
                    i = inicio;
                }
                
                // Agregar el guión y el dígito verificador
                rutFormateado = rutFormateado + '-' + dv;
                this.value = rutFormateado;
                
                // Agregar clase visual de validación
                this.classList.add('input-valid');
                this.classList.remove('input-invalid');
            }
        });

        // Validación básica del formato del RUT
        document.getElementById('rut').addEventListener('blur', function() {
            const rutRegex = /^\d{1,2}\.\d{3}\.\d{3}-[0-9kK]$/;
            if (!rutRegex.test(this.value)) {
                this.classList.add('input-invalid');
                this.classList.remove('input-valid');
                this.setCustomValidity('Formato de RUT inválido. Ejemplo: 12.345.678-9');
            } else {
                this.classList.add('input-valid');
                this.classList.remove('input-invalid');
                this.setCustomValidity('');
            }
        });

        // Validación de la placa patente
        document.getElementById('placa_patente').addEventListener('input', function() {
            // Convertir a mayúsculas y eliminar caracteres no permitidos
            this.value = this.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
            
            // Limitar a 6 caracteres
            if (this.value.length > 6) {
                this.value = this.value.slice(0, 6);
            }
            
            // Validación visual en tiempo real
            if (this.value.length > 0 && this.value.length <= 6) {
                this.classList.add('input-valid');
                this.classList.remove('input-invalid');
                this.setCustomValidity('');
            } else if (this.value.length > 0) {
                this.classList.add('input-invalid');
                this.classList.remove('input-valid');
                this.setCustomValidity('La placa patente debe tener máximo 6 caracteres');
            } else {
                this.classList.remove('input-valid');
                this.classList.remove('input-invalid');
                this.setCustomValidity('');
            }
        });
        

        // Validación de email
        document.getElementById('email').addEventListener('input', function() {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (emailRegex.test(this.value)) {
                this.classList.add('input-valid');
                this.classList.remove('input-invalid');
                this.setCustomValidity('');
            } else if (this.value.length > 0) {
                this.classList.add('input-invalid');
                this.classList.remove('input-valid');
                this.setCustomValidity('Por favor ingrese un email válido');
            } else {
                this.classList.remove('input-valid');
                this.classList.remove('input-invalid');
                this.setCustomValidity('');
            }
        });

        // Validación de confirmación de email
        document.getElementById('confirmar_email').addEventListener('input', function() {
            const email = document.getElementById('email').value;
            if (this.value === email && this.value.length > 0) {
                this.classList.add('input-valid');
                this.classList.remove('input-invalid');
                this.setCustomValidity('');
            } else if (this.value.length > 0) {
                this.classList.add('input-invalid');
                this.classList.remove('input-valid');
                this.setCustomValidity('Los correos electrónicos no coinciden');
            } else {
                this.classList.remove('input-valid');
                this.classList.remove('input-invalid');
                this.setCustomValidity('');
            }
        });

        // Validación de campos de texto requeridos
        const camposTexto = ['nombre', 'apellido_paterno', 'apellido_materno', 'calle', 'numero'];
        camposTexto.forEach(campo => {
            document.getElementById(campo).addEventListener('input', function() {
                if (this.value.trim().length > 0) {
                    this.classList.add('input-valid');
                    this.classList.remove('input-invalid');
                    this.setCustomValidity('');
                } else {
                    this.classList.add('input-invalid');
                    this.classList.remove('input-valid');
                    this.setCustomValidity('Este campo es obligatorio');
                }
            });
        });

        // Validación del campo comuna
        document.getElementById('comuna').addEventListener('change', function() {
            if (this.value) {
                this.classList.add('input-valid');
                this.classList.remove('input-invalid');
                this.setCustomValidity('');
            } else {
                this.classList.add('input-invalid');
                this.classList.remove('input-valid');
                this.setCustomValidity('Por favor seleccione una comuna');
            }
        });
        
        // Validación del teléfono
        document.getElementById('telefono').addEventListener('input', function() {
            this.value = this.value.replace(/[^0-9]/g, '');
            const container = this.closest('.telefono-container');
            
            if (this.value.length === 9) {
                this.setCustomValidity('');
                container.classList.add('input-valid');
                container.classList.remove('input-invalid');
            } else {
                this.setCustomValidity('El número debe tener 9 dígitos');
                container.classList.add('input-invalid');
                container.classList.remove('input-valid');
            }
        });

        // Manejo del envío del formulario
        document.querySelector('form').addEventListener('submit', function(e) {
        // Ya no necesitamos actualizar el campo oculto
            
            // Continuar con el envío normal del formulario
            const submitButton = document.querySelector('.submit-button');
            submitButton.disabled = true;
            submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Procesando...';
            
            // No prevenimos el evento por defecto para permitir el envío normal del formulario
        });
        
        // Hacer desaparecer los mensajes de alerta y mostrar animación
        document.addEventListener('DOMContentLoaded', function() {
            const alertElement = document.querySelector('.alert');
            const modalOverlay = document.querySelector('.modal-overlay');
            const modalClose = document.querySelector('.modal-close');
            
            if (alertElement && alertElement.classList.contains('alert-success')) {
                // Mostrar el modal en lugar de la alerta
                setTimeout(function() {
                    alertElement.style.opacity = '0';
                    
                    // Después de que se desvanezca la alerta, mostrar el modal
                    setTimeout(function() {
                        modalOverlay.style.display = 'flex';
                        
                        // Agregar evento al botón de cierre
                        modalClose.addEventListener('click', function() {
                            modalOverlay.style.display = 'none';
                            
                            // Mostrar la animación de carga después de cerrar el modal
                            document.querySelector('.loading-container').style.display = 'flex';
                            
                            // Esperar 3 segundos y redireccionar
                            setTimeout(function() {
                                window.location.href = 'https://www.melipilla.cl';
                            }, 3000);
                        });
                    }, 500);
                }, 1000);
            } else if (alertElement) {
                // Para mensajes de error, solo ocultar después de un tiempo
                setTimeout(function() {
                    alertElement.style.transition = 'opacity 0.5s ease-out';
                    alertElement.style.opacity = '0';
                    setTimeout(function() {
                        alertElement.remove();
                    }, 500);
                }, 2000);
            }
        });
    </script>

    <script>
            // Autocompletado para el campo de comuna
            $(document).ready(function() {
                $.getJSON('comunas.json', function(data) {
                    $("#comuna").autocomplete({
                        source: data.comunas,
                        minLength: 1,
                        select: function(event, ui) {
                            $(this).addClass('input-valid');
                            $(this).removeClass('input-invalid');
                            // Corregir: usar el elemento DOM nativo
                            this.setCustomValidity('');
                        }
                    });
                });
                
                // Validación del campo comuna
                $("#comuna").on('blur', function() {
                    const comunaValue = $(this).val().trim();
                    
                    if (comunaValue.length > 0) {
                        // Verificar si la comuna existe en el JSON
                        $.getJSON('comunas.json', function(data) {
                            if (data.comunas.includes(comunaValue)) {
                                $("#comuna").addClass('input-valid');
                                $("#comuna").removeClass('input-invalid');
                                // Corregir: usar el elemento DOM nativo
                                document.getElementById('comuna').setCustomValidity('');
                            } else {
                                $("#comuna").addClass('input-invalid');
                                $("#comuna").removeClass('input-valid');
                                // Corregir: usar el elemento DOM nativo
                                document.getElementById('comuna').setCustomValidity('Por favor seleccione una comuna válida de la lista');
                            }
                        });
                    } else {
                        $(this).addClass('input-invalid');
                        $(this).removeClass('input-valid');
                        // Corregir: usar el elemento DOM nativo
                        this.setCustomValidity('Este campo es obligatorio');
                    }
                });
            });
        </script>
<!-- Modal de éxito -->
<div class="modal-overlay">
    <div class="modal-content">
        <span class="modal-close">&times;</span>
        <i class="fas fa-check-circle" style="font-size: 48px; color: #28a745; margin-bottom: 20px;"></i>
        <h3>¡Formulario enviado exitosamente!</h3>
        <p>Su solicitud ha sido recibida y está en proceso de revisión.</p>
        <p>En las próximas horas o días recibirá un correo electrónico a su email con la aprobación o rechazo de su solicitud.</p>
    </div>
</div>

<!-- Contenedor de la animación de carga -->
<div class="loading-container">
    <svg class="pl" viewBox="0 0 128 128" width="128px" height="128px" xmlns="http://www.w3.org/2000/svg">
        <defs>
            <linearGradient id="pl-grad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stop-color="hsl(193,90%,55%)"></stop>
                <stop offset="100%" stop-color="hsl(223,90%,55%)"></stop>
            </linearGradient>
        </defs>
        <circle class="pl__ring" r="56" cx="64" cy="64" fill="none" stroke="hsla(0,10%,10%,0.1)" stroke-width="16" stroke-linecap="round"></circle>
        <path class="pl__worm" d="M92,15.492S78.194,4.967,66.743,16.887c-17.231,17.938-28.26,96.974-28.26,96.974L119.85,59.892l-99-31.588,57.528,89.832L97.8,19.349,13.636,88.51l89.012,16.015S81.908,38.332,66.1,22.337C50.114,6.156,36,15.492,36,15.492a56,56,0,1,0,56,0Z" fill="none" stroke="url(#pl-grad)" stroke-width="16" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="44 1111" stroke-dashoffset="10"></path>
    </svg>
</div>
    </body>
</html>
